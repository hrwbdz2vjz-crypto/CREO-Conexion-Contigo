from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

FONDO_SUAVE = "#FAFAFA"
ACENTO_CALIDO = "#E65926"
TEXTO_PRINCIPAL = "#261A0D"
TEXTO_SECUNDARIO = "#66594D"
ALERTA_SUAVE = "#D94033"
TARJETA_FONDO = "#FFFFFF"


@dataclass(frozen=True)
class SupportResource:
    title: str
    description: str
    url: str
    category: str


SUPPORT_RESOURCES = (
    SupportResource(
        "Centros en Naucalpan",
        "Busca consultorios y centros de atención psicológica cerca de ti.",
        "https://www.google.com/maps/search/centros+psicologicos+en+Naucalpan+de+Juarez+Estado+de+Mexico/",
        "location",
    ),
    SupportResource(
        "Centros en Tlalnepantla",
        "Explora opciones de apoyo psicológico en Tlalnepantla y la zona norte.",
        "https://www.google.com/maps/search/centros+psicologicos+en+Tlalnepantla+de+Baz+Estado+de+Mexico/",
        "location",
    ),
    SupportResource(
        "Línea de la Vida · 800 911 2000",
        "Apoyo emocional y orientación en México, disponible las 24 horas.",
        "tel:8009112000",
        "phone",
    ),
    SupportResource(
        "Spotify",
        "Abre música o playlists tranquilas para acompañar tu momento.",
        "https://open.spotify.com/search/relajacion",
        "music",
    ),
    SupportResource(
        "Apple Music",
        "Encuentra música relajante en Apple Music.",
        "https://music.apple.com/us/search?term=relajacion",
        "music",
    ),
)


@dataclass
class ChatMessage:
    text: str
    is_ai: bool


@dataclass
class JournalEntry:
    text: str
    created_at: str
    day: str


@dataclass
class AppState:
    accepted_privacy: bool = False
    selected_tab: int = 0
    messages: list[ChatMessage] = field(default_factory=lambda: [
        ChatMessage(
            "Hola. Soy CREO IA, tu soporte emocional inteligente. ¿Cómo te sientes ahora mismo?",
            True,
        )
    ])
    journal_entries: list[JournalEntry] = field(default_factory=list)
    breathing_step: int = 0

    def add_message(self, text: str) -> None:
        self.messages.append(ChatMessage(text.strip(), False))
        self.messages.append(
            ChatMessage("Te escucho. Estoy aquí para acompañarte; respira profundo.", True)
        )

    def add_journal_entry(self, text: str) -> None:
        now = datetime.now()
        self.journal_entries.insert(
            0,
            JournalEntry(
                text=text.strip(),
                created_at=now.strftime("%d/%m/%Y %H:%M"),
                day=now.date().isoformat(),
            ),
        )

    def journal_streak(self) -> int:
        entry_days = {entry.day for entry in self.journal_entries}
        current_day = date.today()
        streak = 0
        while current_day.isoformat() in entry_days:
            streak += 1
            current_day -= timedelta(days=1)
        return streak

    def advance_breathing(self) -> None:
        self.breathing_step = (self.breathing_step + 1) % 3


BREATHING_STEPS = (
    ("Inhala lentamente", "Llena tus pulmones con calma."),
    ("Sostén", "Quédate aquí un momento. Estás a salvo."),
    ("Exhala despacio", "Suelta el aire y afloja los hombros."),
)
