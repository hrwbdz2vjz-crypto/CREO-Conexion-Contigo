import flet as ft

from models import AppState, FONDO_SUAVE, TARJETA_FONDO
from views.chat import build_chat
from views.diary import build_diary
from views.home import build_home
from views.resources import build_resources
from views.sos import build_sos
from views.welcome import build_welcome


class CreoApp:
    def __init__(self, page: ft.Page):
        self._page = page
        self._state = AppState()
        self._content = ft.Container(expand=True, padding=20)
        self._navigation = ft.NavigationBar(
            selected_index=0,
            bgcolor=TARJETA_FONDO,
            on_change=self._select_tab,
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icons.HOME, label="Inicio"),
                ft.NavigationBarDestination(icon=ft.Icons.BOOK, label="Diario"),
                ft.NavigationBarDestination(icon=ft.Icons.SECURITY, label="SOS"),
                ft.NavigationBarDestination(icon=ft.Icons.PSYCHOLOGY, label="CREO IA"),
                ft.NavigationBarDestination(icon=ft.Icons.LOCATION_ON, label="Ayuda"),
            ],
        )

    def start(self) -> None:
        self._page.title = "CREO IA"
        self._page.bgcolor = FONDO_SUAVE
        self._page.padding = 0
        self._page.theme_mode = ft.ThemeMode.LIGHT
        self._page.window.width = 400
        self._page.window.height = 800
        self._page.controls = [self._content]
        self._render()

    def _select_tab(self, event) -> None:
        self._state.selected_tab = event.control.selected_index
        self._render()

    def _enter_space(self, _) -> None:
        self._state.accepted_privacy = True
        self._page.navigation_bar = self._navigation
        self._render()

    def _open_sos(self, _) -> None:
        self._state.selected_tab = 2
        self._navigation.selected_index = 2
        self._render()

    def _save_journal(self, text: str) -> None:
        self._state.add_journal_entry(text)
        self._render()

    def _send_chat(self, text: str) -> None:
        self._state.add_message(text)
        self._render()

    def _next_breath(self, _) -> None:
        self._state.advance_breathing()
        self._render()

    def _render(self) -> None:
        if not self._state.accepted_privacy:
            self._content.content = build_welcome(self._enter_space)
        elif self._state.selected_tab == 0:
            self._content.content = build_home(self._open_sos)
        elif self._state.selected_tab == 1:
            self._content.content = build_diary(
                self._state.journal_entries,
                self._state.journal_streak(),
                self._save_journal,
            )
        elif self._state.selected_tab == 2:
            self._content.content = build_sos(self._state.breathing_step, self._next_breath)
        elif self._state.selected_tab == 3:
            self._content.content = build_chat(self._state.messages, self._send_chat)
        else:
            self._content.content = build_resources()
        self._page.update()


async def main(page: ft.Page):
    CreoApp(page).start()


ft.run(main)
