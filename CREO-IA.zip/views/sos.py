import flet as ft

from models import ACENTO_CALIDO, BREATHING_STEPS, TARJETA_FONDO, TEXTO_PRINCIPAL, TEXTO_SECUNDARIO


def build_sos(step_index, on_next):
    title, detail = BREATHING_STEPS[step_index]
    return ft.Column(
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        controls=[
            ft.Text("Modo SOS / Crisis", size=36, weight=ft.FontWeight.BOLD, color=TEXTO_PRINCIPAL),
            ft.Text("Detén el ciclo de ansiedad", size=24, weight=ft.FontWeight.BOLD, color=ACENTO_CALIDO),
            ft.Text("Sigue este ritmo, sin prisa.", size=16, color=TEXTO_SECUNDARIO),
            ft.Container(
                width=180,
                height=180,
                alignment=ft.Alignment.CENTER,
                bgcolor=ACENTO_CALIDO,
                border_radius=90,
                content=ft.Column(
                    tight=True,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(ft.Icons.SPA, color=ft.Colors.WHITE, size=38),
                        ft.Text(title, color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                    ],
                ),
            ),
            ft.Text(detail, size=18, color=TEXTO_PRINCIPAL, text_align=ft.TextAlign.CENTER),
            ft.Button(
                content=ft.Text("Siguiente paso"),
                color=ft.Colors.WHITE,
                bgcolor=ACENTO_CALIDO,
                on_click=on_next,
            ),
            ft.Container(
                bgcolor=TARJETA_FONDO,
                padding=16,
                border_radius=16,
                content=ft.Text(
                    "Si estás en peligro inmediato o piensas en hacerte daño, contacta a los servicios de emergencia de tu zona o a una persona de confianza.",
                    color=TEXTO_SECUNDARIO,
                    text_align=ft.TextAlign.CENTER,
                ),
            ),
        ],
    )
