import flet as ft

from models import ACENTO_CALIDO, ALERTA_SUAVE, TARJETA_FONDO, TEXTO_PRINCIPAL


def build_home(on_open_sos):
    return ft.Column(
        controls=[
            ft.Text("Mi Espacio", size=36, weight=ft.FontWeight.BOLD, color=TEXTO_PRINCIPAL),
            ft.Container(
                content=ft.Row(
                    controls=[
                        ft.Icon(ft.Icons.WARNING, color=ft.Colors.WHITE),
                        ft.Column(
                            spacing=2,
                            controls=[
                                ft.Text(
                                    "¿Sientes una crisis o ataque de pánico?",
                                    weight=ft.FontWeight.BOLD,
                                    color=ft.Colors.WHITE,
                                ),
                                ft.Text(
                                    "Toca aquí para iniciar un anclaje guiado.",
                                    size=12,
                                    color=ft.Colors.WHITE,
                                ),
                            ],
                        ),
                    ],
                ),
                bgcolor=ALERTA_SUAVE,
                padding=20,
                border_radius=16,
                ink=True,
                on_click=on_open_sos,
            ),
            ft.Container(
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(ft.Icons.FORMAT_QUOTE, color=ACENTO_CALIDO),
                        ft.Text(
                            "Respira. Estás haciendo lo mejor que puedes, y eso es suficiente.",
                            size=20,
                            color=TEXTO_PRINCIPAL,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ],
                ),
                bgcolor=TARJETA_FONDO,
                padding=30,
                border_radius=20,
                shadow=ft.BoxShadow(spread_radius=1, blur_radius=10, color=ft.Colors.BLACK_12),
            ),
        ],
    )
