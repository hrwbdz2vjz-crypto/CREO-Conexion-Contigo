import flet as ft

from models import (
    ACENTO_CALIDO,
    ALERTA_SUAVE,
    SUPPORT_RESOURCES,
    TARJETA_FONDO,
    TEXTO_PRINCIPAL,
    TEXTO_SECUNDARIO,
)


def _resource_icon(category):
    if category == "phone":
        return ft.Icons.PHONE
    if category == "music":
        return ft.Icons.MUSIC_NOTE
    return ft.Icons.LOCATION_ON


def build_resources():
    resource_cards = []
    for resource in SUPPORT_RESOURCES:
        resource_cards.append(
            ft.Container(
                bgcolor=TARJETA_FONDO,
                padding=16,
                border_radius=16,
                content=ft.Column(
                    spacing=8,
                    controls=[
                        ft.Row(
                            controls=[
                                ft.Icon(_resource_icon(resource.category), color=ACENTO_CALIDO),
                                ft.Text(resource.title, weight=ft.FontWeight.BOLD, color=TEXTO_PRINCIPAL),
                            ],
                        ),
                        ft.Text(resource.description, color=TEXTO_SECUNDARIO),
                        ft.Button(
                            content=ft.Text("Abrir"),
                            color=ft.Colors.WHITE,
                            bgcolor=ACENTO_CALIDO,
                            url=resource.url,
                        ),
                    ],
                ),
            )
        )

    return ft.Column(
        expand=True,
        controls=[
            ft.Text("Ayuda y recursos", size=30, weight=ft.FontWeight.BOLD, color=TEXTO_PRINCIPAL),
            ft.Text("Encuentra apoyo cercano y herramientas para acompañarte.", color=TEXTO_SECUNDARIO),
            ft.Container(
                bgcolor=ALERTA_SUAVE,
                padding=16,
                border_radius=16,
                content=ft.Text(
                    "En una emergencia o si estás en peligro inmediato, llama al 911.",
                    color=ft.Colors.WHITE,
                ),
            ),
            ft.ListView(expand=True, spacing=10, controls=resource_cards),
        ],
    )
