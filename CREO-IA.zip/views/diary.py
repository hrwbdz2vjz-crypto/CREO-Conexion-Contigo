import flet as ft

from models import ACENTO_CALIDO, TARJETA_FONDO, TEXTO_PRINCIPAL, TEXTO_SECUNDARIO


def build_diary(entries, streak, on_save):
    entry_field = ft.TextField(expand=True, multiline=True, min_lines=2, max_lines=4)

    def save_entry(_):
        if entry_field.value.strip():
            on_save(entry_field.value)

    saved_entries = []
    for entry in entries:
        saved_entries.append(
            ft.Container(
                bgcolor=TARJETA_FONDO,
                padding=16,
                border_radius=16,
                content=ft.Column(
                    spacing=6,
                    controls=[
                        ft.Text(entry.created_at, size=12, color=TEXTO_SECUNDARIO),
                        ft.Text(entry.text, color=TEXTO_PRINCIPAL),
                    ],
                ),
            )
        )

    streak_label = f"Racha actual: {streak} {'día' if streak == 1 else 'días'}"
    streak_detail = "Escribe hoy para iniciar tu racha." if streak == 0 else "Cada día que escribes cuenta."

    return ft.Column(
        expand=True,
        controls=[
            ft.Text("Mi Diario", size=36, weight=ft.FontWeight.BOLD, color=TEXTO_PRINCIPAL),
            ft.Container(
                bgcolor=TARJETA_FONDO,
                padding=16,
                border_radius=16,
                content=ft.Column(
                    spacing=4,
                    controls=[
                        ft.Text(streak_label, weight=ft.FontWeight.BOLD, color=ACENTO_CALIDO),
                        ft.Text(streak_detail, color=TEXTO_SECUNDARIO),
                    ],
                ),
            ),
            ft.Text("Escribe sin juzgarte. Tus entradas solo se guardan durante esta sesión.", color=TEXTO_SECUNDARIO),
            ft.Text("¿Qué necesitas expresar hoy?", color=TEXTO_PRINCIPAL),
            ft.Row(
                controls=[
                    entry_field,
                    ft.IconButton(
                        icon=ft.Icons.CHECK,
                        icon_color=ft.Colors.WHITE,
                        bgcolor=ACENTO_CALIDO,
                        on_click=save_entry,
                    ),
                ],
            ),
            ft.ListView(expand=True, spacing=10, controls=saved_entries),
        ],
    )
