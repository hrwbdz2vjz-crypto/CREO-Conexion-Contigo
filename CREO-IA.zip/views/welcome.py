import flet as ft

from models import ACENTO_CALIDO, FONDO_SUAVE, TEXTO_PRINCIPAL, TEXTO_SECUNDARIO


def build_welcome(on_enter):
    return ft.Column(
        expand=True,
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        controls=[
            ft.Icon(ft.Icons.WB_SUNNY, size=80, color=ACENTO_CALIDO),
            ft.Text(
                "Bienvenido a\nCREO IA",
                size=40,
                weight=ft.FontWeight.BOLD,
                color=TEXTO_PRINCIPAL,
                text_align=ft.TextAlign.CENTER,
            ),
            ft.Text(
                "Tu refugio seguro y soporte emocional inteligente.\n\n"
                "Privacidad absoluta: tus notas y conversaciones solo viven durante esta sesión.",
                size=18,
                color=TEXTO_SECUNDARIO,
                text_align=ft.TextAlign.CENTER,
            ),
            ft.Button(
                content=ft.Text("Entrar a mi espacio", size=20, weight=ft.FontWeight.BOLD),
                color=FONDO_SUAVE,
                bgcolor=ACENTO_CALIDO,
                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=30)),
                on_click=on_enter,
            ),
        ],
    )
