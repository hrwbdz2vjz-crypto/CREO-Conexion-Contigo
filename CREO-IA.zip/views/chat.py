import flet as ft

from models import ACENTO_CALIDO, TARJETA_FONDO, TEXTO_PRINCIPAL, TEXTO_SECUNDARIO


def build_chat(messages, on_send):
    input_field = ft.TextField(expand=True, on_submit=lambda _: send_message())

    def send_message():
        if input_field.value.strip():
            on_send(input_field.value)

    bubbles = []
    for message in messages:
        bubbles.append(
            ft.Row(
                alignment=ft.MainAxisAlignment.START if message.is_ai else ft.MainAxisAlignment.END,
                controls=[
                    ft.Container(
                        content=ft.Text(
                            message.text,
                            size=16,
                            color=TEXTO_PRINCIPAL if message.is_ai else ft.Colors.WHITE,
                        ),
                        bgcolor=TARJETA_FONDO if message.is_ai else ACENTO_CALIDO,
                        padding=15,
                        border_radius=15,
                        shadow=ft.BoxShadow(blur_radius=5, color=ft.Colors.BLACK_12),
                    )
                ],
            )
        )

    return ft.Column(
        expand=True,
        controls=[
            ft.Text("CREO IA · Soporte", size=36, weight=ft.FontWeight.BOLD, color=TEXTO_PRINCIPAL),
            ft.Text("Comparte lo que sientes. Este acompañamiento no reemplaza la ayuda profesional.", color=TEXTO_SECUNDARIO),
            ft.ListView(expand=True, spacing=10, auto_scroll=True, controls=bubbles),
            ft.Row(
                controls=[
                    input_field,
                    ft.IconButton(
                        icon=ft.Icons.SEND,
                        icon_color=ft.Colors.WHITE,
                        bgcolor=ACENTO_CALIDO,
                        on_click=lambda _: send_message(),
                    ),
                ],
            ),
        ],
    )
